import pygame
import random
import asyncio
import time

# Initialize Pygame
pygame.init()

BALANCE = 100  # Starting balance
IS_DECK_SHUFFLED = False

# Screen dimensions
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Chitra Games")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (147, 204, 250)
RED = (255, 0, 0)

# Fonts
FONT = pygame.font.Font(None, 36)

# Card ranks and suits
RANKS = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "j", "q", "k", "a"]
SUITS = ["h", "c", "s", "d"]  # Hearts, Clubs, Spades, Diamonds
CARDS = [suit + rank for suit in SUITS for rank in RANKS]

# Card values
CARD_VALUES = {rank: int(rank) if rank.isdigit() else 10 for rank in RANKS}
CARD_VALUES["a"] = 11

# Load card images
CARD_IMAGES = {card: pygame.image.load(f"cards/{card}.png") for card in CARDS}
CARD_BACK = pygame.image.load("cards/back.png")  # Back of the card


# Shuffle cards
def shuffle_deck():
    deck = CARDS[:]
    random.shuffle(deck)
    return deck


# Calculate hand value
def calculate_hand_value(hand):
    value = sum(CARD_VALUES[card[1:]] for card in hand)  # Extract rank using card[1:]
    aces = sum(1 for card in hand if card[1:] == "a")
    while value > 21 and aces:
        value -= 10
        aces -= 1
    return value


# Display text on the screen
def display_text(text, x, y, color=BLACK):
    rendered_text = FONT.render(text, True, color)
    screen.blit(rendered_text, (x, y))


# Display cards
def display_hand(hand, x, y, show_all=True):
    for index, card in enumerate(hand):
        if show_all or index == 0:
            card_image = CARD_IMAGES[card]
        else:
            card_image = CARD_BACK
        screen.blit(card_image, (x + index * 80, y))


def out_of_balance():
    while True:
        screen.fill(GREEN)
        display_text("Blackjack", WIDTH // 2 - 60, 20, BLACK)  # Redraw all necessary elements
        display_text("Thank you for playing", WIDTH // 2 - 160, 200, BLACK)
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_q:
                    pygame.quit()
                    return


def init_deck():
    deck = shuffle_deck()
    return deck


# Main game loop
async def main():
    global BALANCE
    global IS_DECK_SHUFFLED
    global deck
    running = True
    clock = pygame.time.Clock()

    if not IS_DECK_SHUFFLED:
        deck = init_deck()
        IS_DECK_SHUFFLED = True

    player_hand = [deck.pop(), deck.pop()]
    dealer_hand = [deck.pop(), deck.pop()]
    player_turn = True
    game_over = False
    winner = None
    bet = 0
    cards_on_table = 6

    while running:
        screen.fill(GREEN)

        # Draw game info
        display_text("Blackjack", WIDTH // 2 - 60, 20, BLACK)
        display_text(f"Balance: ${BALANCE}", 600, 100, BLACK)
        display_text(f"Bet: ${bet}", 635, 130, BLACK)

        display_hand(dealer_hand, 50, 100, show_all=game_over)  # Dealer's hand
        display_hand(player_hand, 50, 400)  # Player's hand
        display_text(f"Player Total: {calculate_hand_value(player_hand)}", 50, 520)
        display_text(f"Dealer Total: ", 50, 220)

        screen.blit(CARD_BACK, (250, 250))
        for i in range(cards_on_table):
            screen.blit(CARD_BACK, (250 + 7 * i, 250))
        pygame.display.flip()

        # Get bet amount
        input_active = True
        bet_text = ""
        if bet == 0:
            while input_active:
                screen.fill(GREEN)  # Clear the screen
                display_text("Blackjack", WIDTH // 2 - 60, 20, BLACK)  # Redraw all necessary elements
                display_text(f"Balance: ${BALANCE}", 600, 100, BLACK)
                display_text("Please place your bets", 450, 250, BLACK)
                display_text(f"Amount to Bet: ${bet_text}", 500, 300, BLACK)
                display_text(f"Balance: ${BALANCE}", 600, 100, BLACK)
                display_text(f"Dealer Total: ", 50, 220)
                for i in range(6):
                    screen.blit(CARD_BACK, (250 + 7 * i, 250))

                display_hand(dealer_hand, 50, 100, show_all=game_over)  # Dealer's hand
                display_hand(player_hand, 50, 400)  # Player's hand
                display_text(f"Player Total: {calculate_hand_value(player_hand)}", 50, 520)
                pygame.display.flip()  # Update the screen

                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        return
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_RETURN:  # Confirm bet
                            if bet_text.isdigit() and 0 < int(bet_text) <= BALANCE:
                                bet = int(bet_text)
                                BALANCE -= bet
                                input_active = False
                            else:
                                bet_text = ""
                        elif event.key == pygame.K_BACKSPACE:  # Remove last character
                            bet_text = bet_text[:-1]
                        else:
                            bet_text += event.unicode

            display_text("Bet confirmed!", 450, 350, BLACK)
            pygame.display.flip()  # Show confirmation message
            time.sleep(1)  # Pause for 1 second

        if game_over:
            display_text(f"Dealer Total: {calculate_hand_value(dealer_hand)}", 50, 220)
            display_text(winner, WIDTH // 2 - 300, HEIGHT // 2, RED)
            if BALANCE != 0:
                display_text("Press R to Restart or Q to Quit", 400, HEIGHT - 100)
            else:
                display_text("Thank you for playing!", 250, HEIGHT - 350)
                display_text("Press Q to exit", 500, HEIGHT - 75)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if game_over:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r and BALANCE:
                        return "restart"  # Exit and signal to restart
                    elif event.key == pygame.K_q:
                        running = False
            elif player_turn:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_h:  # Hit
                        player_hand.append(deck.pop())
                        cards_on_table -= 1
                        if calculate_hand_value(player_hand) > 21:
                            game_over = True
                            winner = "You Busted! Dealer Wins!"
                    elif event.key == pygame.K_s:  # Stand
                        player_turn = False
                        time.sleep(2)

        if not player_turn and not game_over:
            pygame.display.flip()
            while True:
                screen.fill(GREEN)
                display_text("Blackjack", WIDTH // 2 - 60, 20, BLACK)
                display_text(f"Balance: ${BALANCE}", 600, 100, BLACK)
                display_text(f"Bet: ${bet}", 635, 130, BLACK)

                display_hand(dealer_hand, 50, 100, show_all=True)  # Dealer's hand
                display_hand(player_hand, 50, 400)  # Player's hand
                display_text(f"Your Total: {calculate_hand_value(player_hand)}", 50, 520)
                display_text(f"Dealer's Total: {calculate_hand_value(dealer_hand)}", 50, 220)

                screen.blit(CARD_BACK, (250, 250))
                for i in range(cards_on_table):
                    screen.blit(CARD_BACK, (250 + 7 * i, 250))
                pygame.display.flip()

                if calculate_hand_value(dealer_hand) < 17:
                    dealer_hand.append(deck.pop())
                    cards_on_table -= 1
                    time.sleep(2)

                player_total = calculate_hand_value(player_hand)
                dealer_total = calculate_hand_value(dealer_hand)
                if calculate_hand_value(dealer_hand) >= 17:
                    game_over = True
                    if dealer_total > 21 or player_total > dealer_total:
                        winner = "You Win!"
                        BALANCE += bet * 2
                        break
                    elif dealer_total == player_total:
                        winner = "It's a Tie!"
                        BALANCE += bet  # Return bet
                        break
                    else:
                        winner = "Dealer Wins!"
                        break

        clock.tick(30)
        await asyncio.sleep(0)

    pygame.quit()


async def game_loop():
    while True:
        result = await main()  # Run the game
        if result != "restart":
            break


# Run the game
if __name__ == "__main__":
    asyncio.run(game_loop())
