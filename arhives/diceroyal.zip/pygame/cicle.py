# Simple pygame program

# https://realpython.com/pygame-a-primer/

import pygame

from pygame.locals import (
    K_UP,
    K_DOWN,
    K_LEFT,
    K_RIGHT,
    K_ESCAPE,
    KEYDOWN,
    QUIT,
    K_KP_ENTER,
    K_RETURN,
    K_SPACE,
    K_0,
    K_1,
    K_2,
    K_3,
    K_4,
    K_5,
    K_6,
    K_7,
    K_8,
    K_9
)

pygame.init()
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
CIRCLE1_RADIUS = 70
CIRCLE2_RADIUS = 30
DICE_SIZE = 160
DICE_HALF_SIZE = DICE_SIZE/2
FONT_SIZE_TITLE = 30

# Set up the drawing window
screen = pygame.display.set_mode([SCREEN_WIDTH, SCREEN_HEIGHT])
pygame.display.set_caption('Dice Royal')

font1 = pygame.font.SysFont('freesanbold.ttf', FONT_SIZE_TITLE)
textCaption = font1.render('Dice Royal', True, (255, 0, 215))
textRect_textCaption = textCaption.get_rect()
textRect_textCaption.center = (SCREEN_WIDTH/2, FONT_SIZE_TITLE)

textPlayer = font1.render('Miruna Iliescu', True, (255, 0, 215))
textRect_textPlayer = textPlayer.get_rect()
textRect_textPlayer.center = (DICE_HALF_SIZE, FONT_SIZE_TITLE)

# Run until the user asks to quit
running = True
show_blackdice3 = False
show_blackdice4 = False
show_dice_5 = False
show_dice_6 = False
bet = 0
balance = 10000
while running:

    # Did the user click the window close button?
    for event in pygame.event.get():
        if event.type == KEYDOWN:
            show_blackdice3 = False
            show_dice_4 = False
            show_dice_5 = False
            show_dice_6 = False
            
            if event.key == K_ESCAPE:
                running = False
            if event.key == K_RETURN:
                show_blackdice4 = True

            if event.key == K_UP:
                bet = bet + 1
                if bet > balance:
                    bet = balance
            if event.key == K_DOWN:
                bet = bet - 1
                if bet < 0:
                    bet = 0
            if event.key == K_RIGHT:
                bet = bet + 5
                if bet > balance:
                    bet = balance  
            if event.key == K_LEFT:
                bet = bet - 5
                if bet < 0:
                    bet = 0
            if event.key == K_SPACE:
                bet = bet * 2
                if bet > balance:
                    bet = balance  
            if event.type == pygame.QUIT:
                running = False
            if event.key == K_0:
                bet = 0
            if event.key == K_1:
                bet = 1
            if event.key == K_2:
                bet = 2
            if event.key == K_3:
                bet = 3
            if event.key == K_4:
                bet = 4
            if event.key == K_5:
                bet = 5
            if event.key == K_6:
                bet = 10
            if event.key == K_7:
                bet = 20
            if event.key == K_8:
                bet = 50
            if event.key == K_9:
                bet = 100           
    # Fill the background with white
    screen.fill((255, 255, 255))
    screen.blit(textCaption, textRect_textCaption)
    screen.blit(textPlayer, textRect_textPlayer)
    
    pygame.draw.circle(screen, (0, 0, 255), (SCREEN_WIDTH/2, SCREEN_HEIGHT/2), CIRCLE1_RADIUS)
    pygame.draw.circle(screen, (255, 255, 255), (SCREEN_WIDTH/2, SCREEN_HEIGHT/2), CIRCLE1_RADIUS-2)
    
    textBet = font1.render(str(bet), True, (255, 0, 215))
    textRect_bet = textBet.get_rect()
    textRect_bet.center = (SCREEN_WIDTH/2, SCREEN_HEIGHT/2)
    screen.blit(textBet, textRect_bet)
    
    textBalance = font1.render(str(balance), True, (255, 0, 215))
    textRect_balance = textBalance.get_rect()
    textRect_balance.center = (SCREEN_WIDTH - DICE_HALF_SIZE, FONT_SIZE_TITLE)
    screen.blit(textBalance, textRect_balance)

    black_dice3 = pygame.Surface((160, 160))
    black_dice3.fill((0, 0, 0))
    pygame.draw.circle(black_dice3, (255, 0, 255), (30, 30), 10)
    pygame.draw.circle(black_dice3, (255, 0, 255), (80, 80), 10)
    pygame.draw.circle(black_dice3, (255, 0, 255), (130, 130), 10)
    rect = black_dice3.get_rect()
    if show_blackdice3:
        screen.blit(black_dice3, (SCREEN_WIDTH - DICE_SIZE - DICE_HALF_SIZE, SCREEN_HEIGHT/2- DICE_HALF_SIZE))
    
    black_dice4 = pygame.Surface((160, 160))
    black_dice4.fill((0, 0, 0))
    pygame.draw.circle(black_dice4, (255, 0, 255), (30, 30), 10)
    pygame.draw.circle(black_dice4, (255, 0, 255), (30, 130), 10)
    pygame.draw.circle(black_dice4, (255, 0, 255), (130, 30), 10)
    pygame.draw.circle(black_dice4, (255, 0, 255), (130, 130), 10)
    rect = black_dice4.get_rect()
    if show_blackdice4:
        screen.blit(black_dice4, (SCREEN_WIDTH - DICE_SIZE - DICE_HALF_SIZE, SCREEN_HEIGHT/2- DICE_HALF_SIZE))
    
    surf5 = pygame.Surface((160, 160))
    surf5.fill((0, 0, 0))
    pygame.draw.circle(surf5, (255, 0, 255), (30, 30), 10)
    pygame.draw.circle(surf5, (255, 0, 255), (30, 130), 10)
    pygame.draw.circle(surf5, (255, 0, 255), (80, 80), 10)
    pygame.draw.circle(surf5, (255, 0, 255), (130, 30), 10)
    pygame.draw.circle(surf5, (255, 0, 255), (130, 130), 10)
    rect = surf5.get_rect()
    if show_dice_5:
        screen.blit(surf5, (SCREEN_WIDTH - DICE_SIZE - DICE_HALF_SIZE, SCREEN_HEIGHT/2- DICE_HALF_SIZE))
    
    surf6 = pygame.Surface((160, 160))
    surf6.fill((0, 0, 0))
    pygame.draw.circle(surf6, (255, 0, 255), (30, 30), 10)
    pygame.draw.circle(surf6, (255, 0, 255), (30, 130), 10)
    pygame.draw.circle(surf6, (255, 0, 255), (30, 80), 10)
    pygame.draw.circle(surf6, (255, 0, 255), (130, 80), 10)
    pygame.draw.circle(surf6, (255, 0, 255), (130, 30), 10)
    pygame.draw.circle(surf6, (255, 0, 255), (130, 130), 10)
    rect = surf6.get_rect()
    if show_dice_6:
        screen.blit(surf6, (SCREEN_WIDTH - DICE_SIZE - DICE_HALF_SIZE, SCREEN_HEIGHT/2- DICE_HALF_SIZE))
    
    # Draw a solid blue circle in the center


    # Flip the display
    pygame.display.flip()

# Done! Time to quit.
pygame.quit()
